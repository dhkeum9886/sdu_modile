package chap02.section4.extras

fun main() {

    val num1 = 13.0
    val num2 = 3.0
    var result: Double

    result = num1 + num2
    println("num1 + num2 = $result")

    result = num1 - num2
    println("num1 - num2 = $result")

    result = num1 * num2
    println("num1 * num2 = $result")

    result = num1 / num2
    println("num1 / num2 = $result")

    result = num1 % num2
    println("num1 % num2 = $result")
}