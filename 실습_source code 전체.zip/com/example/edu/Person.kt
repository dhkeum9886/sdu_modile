package com.example.edu

class Person(val name: String, val age: Int)


