package chap07.coffeeMaker

interface Pump {
    fun pump()
}
