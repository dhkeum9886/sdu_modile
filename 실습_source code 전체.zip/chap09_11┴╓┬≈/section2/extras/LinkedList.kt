package chap09.section2.extras

import java.util.*

fun main() {
    val list1: List<Int> = LinkedList<Int>()
    val list2: List<Int> = ArrayList<Int>()

}