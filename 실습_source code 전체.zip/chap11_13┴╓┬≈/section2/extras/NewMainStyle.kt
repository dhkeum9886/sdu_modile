package chap11.section2.extras

import kotlinx.coroutines.runBlocking

fun main() = runBlocking {
    println("Hello World!")
}
